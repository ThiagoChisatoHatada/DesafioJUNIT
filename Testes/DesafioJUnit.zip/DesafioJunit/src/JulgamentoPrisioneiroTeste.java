import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.TestCase;

public class JulgamentoPrisioneiroTeste extends TestCase{

	@Test
	public void testJulgamento() {
		String respostaPrisioneiroA ="Culpado";
		String respostaPrisioneiroB ="Culpado";
		
		JulgamentoPrisioneiro jp = new JulgamentoPrisioneiro();
		
		int penaSuspeitoA = jp.calculaPena(respostaPrisioneiroA, respostaPrisioneiroB);
		int penaSuspeitoB = jp.calculaPena(respostaPrisioneiroA, respostaPrisioneiroB);
	
		assertEquals(5, penaSuspeitoA);
		assertEquals(5, penaSuspeitoB);
	}

}
